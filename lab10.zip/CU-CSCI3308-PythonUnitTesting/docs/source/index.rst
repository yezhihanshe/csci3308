.. Text Processor documentation master file, created by
   sphinx-quickstart on Wed Jun 11 08:27:20 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Text Processor Docs
==========================================

.. toctree::
   :maxdepth: 1

TextProc
========
.. automodule:: textproc
    :members:
    :undoc-members:
    :special-members:
    :show-inheritance:

Contents
=========

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
