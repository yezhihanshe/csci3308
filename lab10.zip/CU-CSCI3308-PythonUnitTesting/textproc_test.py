#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Andy Sayler
# Summer 2014
# CSCI 3308
# Univerity of Colorado
# Text Processing Module

import unittest
import textproc

class TextprocTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_init(self):
        text = "100"
        p = textproc.Processor(text)
        self.assertEqual(p.text, text, "'text' does not match input")

    # Add Your Test Cases Here...
    def test_count(self):
        string = "100hdxcytdt"
        a = textproc.Processor(string)
        self.assertEqual(a.count(),11)

    def test_count_alpha(self):
        alpha = "Jzz0917"
        b = textproc.Processor(alpha)
        self.assertEqual(b.count_alpha(),3)

    def test_count_numeric(self):
        numeric = "jzz2917"
        c = textproc.Processor(numeric)
        self.assertEqual(c.count_numeric(),4)

    def test_count_vowels(self):
	vowels= "jzza0917"
	d= textproc.Processor(vowels)
        self.assertEqual(d.count_vowels(),1)

    def test_is_phonenumber(self):
        phonenumber = "3038620108"
        e = textproc.Processor(phonenumber)
        self.assertTrue(e.is_phonenumber())
    

# Main: Run Test Cases
if __name__ == '__main__':
    unittest.main()
