#hanye han
#!/bin/bash


# awk command to calculate averages of each student and sort ouput
awk '
BEGIN {}
{ $5 = ($4+$5+$6)/3 }
{ print $5, "[" $1 "]", $3",",$2 }
END {}
' data.txt | sort -k3 -k4 -k2
