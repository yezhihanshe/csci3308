
file="$1"

egrep '[0-9]$' ${file} | wc -l

egrep '^[^aiueoAIUEO]' ${file} | wc -l

egrep '^[A-Za-z]{12}$' ${file} | wc -l

egrep '^[0-9]{3}-[0-9]{3}-[0-9]{4}$' ${file} |wc -l

egrep '303-[0-9]{3}-[0-9]{4}' ${file} |wc -l

egrep '^[^A,E,I,O,U,a,e,i,i,o,u]+\w+[0-9]$' ${file} |wc -l

egrep '^[A-Za-z_.% -+0-9]*@geocities.com$' ${file} |wc -l
