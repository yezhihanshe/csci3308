#hanye han
#!/bin/bash
while read a b c d e f
do
x=d
y=e
z=f
p=$((x+y+z))
q=$((p/3))
echo "$q [$a] $c, $b"
done < data.txt | sort -k3 -k2 # sort the output data according to last name
